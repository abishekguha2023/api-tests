import { test, expect, APIRequest,APIRequestContext, request } from '@playwright/test';

import { before } from 'node:test';
let apireqContext: APIRequestContext;

test.beforeAll(async() =>{
  apireqContext = await request.newContext({
       baseURL: 'https://dog.ceo/api/breeds/image/random',
       ignoreHTTPSErrors: true
     });
});

test('AP I test', async () =>{
  const response = await apireqContext.get('');
  console.log("****" + await response.text())
  expect(response.status()).toBe(200);
});

